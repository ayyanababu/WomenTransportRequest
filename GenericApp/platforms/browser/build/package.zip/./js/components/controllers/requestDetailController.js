define(function(require){
  var NavigationActions = require ("actions/navigationActions");
  var NavigationStore = require ("stores/navigationStore");
  var NavigationConstants = require ("constants/navigationConstants");

  var requestDetailController = React.createClass ({displayName: "requestDetailController",
    componentDidMount: function () {
      NavigationStore.addChangeListener (NavigationConstants.Back_Click_Event,this._onLeftButtonClick);
    },

    componentWillUnmount: function () {
        NavigationStore.removeChangeListener (NavigationConstants.Back_Click_Event,this._onLeftButtonClick);
    },
    _onLeftButtonClick:function()
    {
      NavigationActions.popController();
    },
    onDisapprove:function(){
        this.props.disApprove(this.props.data);
        NavigationActions.popController();
    },
    onApprove:function()
    {
        this.props.approve(this.props.data);
        NavigationActions.popController();
    },
    render: function() {
      return(
        React.createElement("div", {className: "requestDetailView"}, 
            React.createElement("div", {className: "requestDetailViewRow"}, 
              React.createElement("div", {className: "reqLabel"}, getString("employeeName")), 
              React.createElement("div", {className: "reqValue"}, this.props.data.employeeName)
            ), 
            React.createElement("div", {className: "requestDetailViewRow"}, 
              React.createElement("div", {className: "requestDetailViewCol"}, 
                React.createElement("div", {className: "reqLabel"}, getString("managerName")), 
                React.createElement("div", {className: "reqValue"}, this.props.data.managerName)
              ), 
              React.createElement("div", {className: "requestDetailViewCol"}, 
                React.createElement("div", {className: "reqLabel"}, getString("department")), 
                React.createElement("div", {className: "reqValue"}, "PE/PS")
              )
            ), 
            React.createElement("div", {className: "requestDetailViewRow"}, 
              React.createElement("div", {className: "requestDetailViewCol"}, 
                React.createElement("div", {className: "reqLabel"}, getString("date")), 
                React.createElement("div", {className: "reqValue"}, this.props.data.requestedDate)
              ), 
              React.createElement("div", {className: "requestDetailViewCol"}, 
                React.createElement("div", {className: "reqLabel"}, getString("requestedTime")), 
                React.createElement("div", {className: "reqValue"}, this.props.data.requestedTime)
              )
            ), 
            React.createElement("div", {className: "requestDetailViewRow"}, 
              React.createElement("div", {className: "reqLabel"}, getString("transportType")), 
              React.createElement("div", {className: "reqValue"}, "Company Transport")
            ), 
            React.createElement("div", {className: "requestDetailViewRow expandRow"}, 
              React.createElement("div", {className: "reqLabel"}, getString("businessJustification")), 
              React.createElement("div", {className: "reqValue"}, this.props.data.businessJustification)
            ), 
            React.createElement("div", {className: "requestDetailViewRow expandRow"}, 
              React.createElement("div", {className: "requestDetailViewCol"}, 
                React.createElement("div", {className: "reqLabel"}, getString("toAddress")), 
                React.createElement("div", {className: "reqValue"}, this.props.data.fromPlace)
              )
            ), 

            React.createElement("div", {className: "requestDetailViewRow"}, 
              React.createElement("div", {className: "requestDetailViewCol"}, 
                  React.createElement("div", {className: "requestAccept", id: "rejectBtn", onClick: this.onDisapprove})
              ), 
              React.createElement("div", {className: "requestDetailViewCol"}, 
                React.createElement("div", {className: "requestAccept", id: "acceptBtn", onClick: this.onApprove})
              )
            )
        )
      );
    }
  });

  return requestDetailController;

});
