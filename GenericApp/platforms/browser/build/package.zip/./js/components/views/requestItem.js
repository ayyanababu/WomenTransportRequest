define(function(require){

  var requestItem = React.createClass ({displayName: "requestItem",
    onClick:function(){
      this.props.onItemClick(this.props.id);
    },
    render: function() {
      return(
        React.createElement("div", {className: "requestItem", onClick: this.onClick, id: this.props.id}, 
            React.createElement("div", {className: "requestItemDiv requesterName"}, this.props.data.employeeName), 
            React.createElement("div", {className: "requestItemDiv requestDate"}, " ", this.props.data.requestedDate), 
            React.createElement("div", {className: "requestItemDiv requesterManager"}, "/", this.props.data.managerName), 
            React.createElement("div", {className: "requestItemDiv requesterGroup"}, "PE/PS")
        )
      );
    }
  });

  return requestItem;

});
