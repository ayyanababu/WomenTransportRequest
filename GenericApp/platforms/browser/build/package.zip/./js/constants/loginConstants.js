define (function () {
    return {
        Login_Authenticate: 'login_authenticate',
        Login_Reissue:'login_reissue',
        Logout: 'login_logout',
        Login_Issued_Event: 'login_issued_event',
        Logout_Error_Event: 'logout_error_event',
        Pre_Session_Expiry_Event: 'pre_session_expiry_event',
    };
});
