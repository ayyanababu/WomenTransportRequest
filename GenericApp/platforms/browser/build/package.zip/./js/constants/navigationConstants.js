define (function () {
    return {
        Navigation_PUSH: "navigation_push",
        Navigation_POP: "navigation_pop",
        Navigation_Clear: "navigation_clear",
        Navigation_ChangeRoot:"navigation_change_root",
        Navigation_PresentPopup:"navigation_present_popup",
        Navigation_RemovePopup:"navigation_remove_popup",
        Navigation_PresentPrompt:"navigation_present_prompt",
        Navigation_RemovePrompt:"navigation_remove_prompt",
        Change_Event: 'navigation_change',
        Back_Click_Event:'back_click_event',
        Right_Click_Event:'right_click_event'
    };
});
