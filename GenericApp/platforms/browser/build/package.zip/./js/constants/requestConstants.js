define (function () {
    return {
        Request_Actions: 'request_actions',
        Request_Send_Action: 'request_send_action',
        Request_Actions_Event: 'request_actions_event',
        Request_Send_Event: 'request_send_event',
    };
});
